$$.widget = {
  name: 'IP CameraPro',
  version: '1.2',
  author: 'tuicemen',
  release: '2019',
  icon: 'pages/control/widgets/tuicemen/icons/ProCamera.png'
};

var popupisopen = false;
var requestPopupOpen = false;
var imageurl = $$.widget.icon;

var orientate ='Off'
$$.onStart = function() {
   var link = $$.module.prop('IpCamera.HomeURL');
  // Settings button click
  $$.field('settings').on('click', function() {
    $$.ui.EditModule($$.module);
  });
  //on description click
  $$.field('description').on('click', function() {
  //$$.module.command('Camera.Home');
        if (link != '') {
       $$.signalActity('description')
           window.open(link.Value);
                }
    
   });    

 // Preset1 button click
  $$.field('Preset1').on('click', function () {
    $$.module.command('Camera.Preset1');
    $$.signalActity('Preset1')
  });
  // Preset2 button click
  $$.field('Preset2').on('click', function () {
    $$.module.command('Camera.Preset2');
    $$.signalActity('Preset2')
  });
  // Preset3 button click
  $$.field('Preset3').on('click', function () {
    $$.module.command('Camera.Preset3');
    $$.signalActity('Preset3')
 });
  // Preset4 button click
  $$.field('Preset4').on('click', function () {
    $$.module.command('Camera.Preset4');
    $$.signalActity('Preset4')
 });
  // SnapShot button click
  $$.field('SnapShot').on('click', function () {
  //$$.ui.EditModule($$.module);
    $$.module.command('Camera.SnapShot');
    $$.signalActity('SnapShot')
 });
   
  // Initialize camera live popup
  $$.popup.on('popupbeforeposition', function() {
    popupisopen = true;
    requestPopupOpen = false;
    $$.popup.field('camerapicture').attr('src', imageurl + '?' + (new Date().getTime()));
  });
  $$.popup.on('popupafterclose', function() { popupisopen = false; $.mobile.loading('hide'); });
  $$.popup.field('camerapicture').attr('src', imageurl + '?' + (new Date().getTime())).load(function () {
    if (requestPopupOpen) {
      $$.popup.field('camerapicture').css({ width: 'auto', height: 'auto'});
      $$.popup.popup('open');
      if (requestResize) {
        requestResize = false;
        var w = $$.popup.field('camerapicture').width()+200;
        var h = $$.popup.field('camerapicture').height()+200;
        var availW = $(window).width()-160;
        var availH = availW * (h / w);
        if (w/h >= 1 && $(window).width() / $(window).height() >= 1) {
          availH = $(window).height()-160;
          availW = availH * (w / h);
          if ($(window).width() / $(window).height() >= 1)
            $$.popup.field('camerapicture').css({ width: availW+'px', height: 'auto'});
          else
            $$.popup.field('camerapicture').css({ width: availW*(availH/h)+'px', height: 'auto'});
        } else {
          if ($(window).width() / $(window).height() >= 1)
            $$.popup.field('camerapicture').css({ width: availW+'px', height: 'auto'});
          else
            $$.popup.field('camerapicture').css({ width: availH/(h/w)+'px', height: 'auto'});
        }
        setTimeout(function(){
          $$.popup.popup('reposition', { positionTo: 'window', animate: 'true' });
        }, 500);
      }
    } else if (popupisopen) {
       
      $.mobile.loading('hide');
      setTimeout(function () {
        $$.popup.field('camerapicture').attr('src', imageurl + '?' + (new Date().getTime()));
        if (orientate ==='On') {$$.popup.field('camerapicture').css({'transform': 'rotate(90deg)'});
      $$.popup.field('camerapicture').css({ width: '900px', height: '900px'});
                                 }                 
                                 }, 80);
    }
  }).error(function () {
    if (popupisopen) {
      $.mobile.loading('show', { text: 'Error connecting to camera', textVisible: true });
      setTimeout(function () {
        $$.popup.field('camerapicture').attr('src', imageurl + '?' + (new Date().getTime()));
      }, 2000);
    }
  });

  // When widget is clicked control popup is shown
  $$.field('camerapicturepreview').on('click', function() {
    
    $.mobile.loading('show', { text: 'Connecting to camera', textVisible: true });
    requestPopupOpen = true;
    requestResize = true;
    $$.popup.field('camerapicture').attr('src', imageurl + '?' + (new Date().getTime()));
   
  });
  $$.field('camerapicturepreview').load(function() {
    if ($$.container.is(':visible')) {
      setTimeout(function () {
        $$.field('camerapicturepreview').attr('src', imageurl + '?' + (new Date().getTime()));
      }, 500);
    }
  }).error(function () {
    if ($$.container.is(':visible')) {
      setTimeout(function () {
        $$.field('camerapicturepreview').attr('src', imageurl + '?' + (new Date().getTime()));
      }, 500);
    }
  });

orientate = $$.module.prop('IpCamera.Orientation').Value;
 if (orientate !='On')$$.field('camerapicturepreview').css({'transform': 'rotate(0deg)'});
  else  {$$.field('camerapicturepreview').css({'transform': 'rotate(90deg)'});
   $$._widget.css('width', '172');
     $$._widget.css('height', '286');
      $$.field('camerapicturepreview').css('height', '300');
      $$.field('camerapicturepreview').css({'transform': 'rotate(90deg)'});
    
        }
                                          

  $$.field('sizetoggle').on('click', function(){
  if (orientate !='On'){  
    if ($$._widget.data('enlarged') === true){           
      $$._widget.css('width', '');
      $$._widget.css('height', '');
      $$.field('camerapicturepreview').css('height', '172');
      $$._widget.data('enlarged', false);
    } 
         else{
      $$._widget.css('width', '430');
      $$._widget.css('height', '290');
      $$.field('camerapicturepreview').css('height', '282');
      $$._widget.data('enlarged', true);
    }
  } else{      
       if ($$._widget.data('enlarged') === true){           
      $$._widget.css('width', '172');
      $$._widget.css('height', '286');
      $$.field('camerapicturepreview').css('height', '300');
      $$._widget.data('enlarged', false);
    } 
    else{
      $$._widget.css('width', '420');
      $$._widget.css('height', '500');
      $$.field('camerapicturepreview').css('height', '565');
      $$._widget.data('enlarged', true);
    }
  }
    // force content relayout
    $$.container.parent().parent().isotope('layout')
  });

  // Set the camera image URL
  var cameraUrl = $$.module.prop('IpCamera.ImageURL');
  if (cameraUrl != null) imageurl = cameraUrl.Value;
  else imageurl = '/api/' + $$.module.Domain + '/' + $$.module.Address + '/Camera.GetPicture/';
  if (imageurl.indexOf('?') > 0) imageurl += '&';
}

$$.onRefresh = function() {
  $$.field('camerapicturepreview').attr('src', imageurl + '?');
   $$.field('description').html('Camera ' + $$.module.Address);
  $$.field('name').html($$.module.Name);
  $$.popup.field('name').html($$.module.Name);
 
}

$$.onUpdate = function(parameter, value) {
  // TODO: ..
  $$.signalActity('name');
}

$$.onStop = function() {
  // TODO: ..
}
